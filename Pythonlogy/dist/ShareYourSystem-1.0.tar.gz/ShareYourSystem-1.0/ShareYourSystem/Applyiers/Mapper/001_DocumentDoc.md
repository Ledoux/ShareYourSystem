
<!--
FrozenIsBool False
-->

#Mapper

##Doc
----


> A Mapper instance maps an apply and so "grinds" a MappingArgDictsList 
> to a method.
> 
> 

----

<small>
View the Mapper notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Mapper.ipynb)
</small>

