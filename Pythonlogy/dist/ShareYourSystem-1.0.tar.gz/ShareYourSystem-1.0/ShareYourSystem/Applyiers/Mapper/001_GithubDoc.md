
<!--
FrozenIsBool False
-->

View the Mapper sources on [Github](https://github.com/Ledoux/ShareYourSystem/tree/master/ShareYourSystem/Applyiers/Installer)

