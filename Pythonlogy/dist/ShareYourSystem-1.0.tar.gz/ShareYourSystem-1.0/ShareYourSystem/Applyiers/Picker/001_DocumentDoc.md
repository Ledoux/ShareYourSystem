
<!--
FrozenIsBool False
-->

#Picker

##Doc
----


> 
> A Picker maps a __getitem__
> 
> 

----

<small>
View the Picker notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Picker.ipynb)
</small>

