
<!--
FrozenIsBool False
-->

##Concept and SubModules family

<script type="text/javascript">

	var HrefStr=window.location.href;
	//alert(window.location.href)

	if(HrefStr == "http://shareyoursystem.ouvaton.org/site/LibraryReference/Applyiers/"){

	    //alert('Ouvaton')
	    document.write("from ")
	    document.write("http://shareyoursystem.ouvaton.org/slides/ ")
	    document.write("<iframe width=\"725\" height=\"300\" src=\"")
	    document.write("http://shareyoursystem.ouvaton.org")
	    document.write("/slides/Applyiers.php\"></iframe>")
	}
	else if(HrefStr == "http://127.0.0.1:8000/LibraryReference/Applyiers/"){

        //alert('Localhost')
        document.write("from ")
        document.write("localhost mkdocs but direct to ouvaton")
        document.write("<iframe width=\"725\" height=\"300\" src=\"")
        document.write("http://shareyoursystem.ouvaton.org")
        document.write("/slides/Applyiers.php\"></iframe>")
    }
    else
    {

        //alert('Local')
	    document.write("from ")
	    document.write("/Users/ledoux/Documents/ShareYourSystem/Ouvaton/ ")
	    document.write("<iframe width=\"725\" height=\"300\" src=\"")
	    document.write("/Users/ledoux/Documents/ShareYourSystem/Ouvaton/")
	    document.write("Applyiers.html\"></iframe>")

    }

</script>

<small>
View the Applyiers concept on <a href="http://shareyoursystem.ouvaton.org/slides/Applyiers.php" target="_blank">Ouvaton</a>
</small>

