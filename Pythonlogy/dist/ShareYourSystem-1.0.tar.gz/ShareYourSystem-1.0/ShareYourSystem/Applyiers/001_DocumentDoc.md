
<!--
FrozenIsBool False
-->

#Applyiers

##Doc
----


> 
> The Classors help for decorating a Class. 
> 
> 
> 

----

<small>
View the Applyiers notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Applyiers.ipynb)
</small>

