
<!--
FrozenIsBool False
-->

#Commander

##Doc
----


> 
> A Commander gather Variables to set them with an UpdateList.
> The command process can be AllSetsForEach (ie a map of the update succesively for each)
> or a EachSetForAll (ie each set is a map of each).
> 
> 

----

<small>
View the Commander notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Commander.ipynb)
</small>

