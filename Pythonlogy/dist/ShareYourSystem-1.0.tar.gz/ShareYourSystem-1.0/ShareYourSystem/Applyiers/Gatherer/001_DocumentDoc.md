
<!--
FrozenIsBool False
-->

#Gatherer

##Doc
----


> 
> A Gatherer is able to pick several times and flat all the results in a one dimension of ItemTuplesList
> 
> 

----

<small>
View the Gatherer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Gatherer.ipynb)
</small>

