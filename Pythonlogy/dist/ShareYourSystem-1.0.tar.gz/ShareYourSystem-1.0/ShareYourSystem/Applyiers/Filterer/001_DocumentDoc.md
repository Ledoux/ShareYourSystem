
<!--
FrozenIsBool False
-->

#Filterer

##Doc
----


> 
> A Filterer pick and 
> 
> 

----

<small>
View the Filterer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Filterer.ipynb)
</small>

