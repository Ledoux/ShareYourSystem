
<!---
FrozenIsBool True
-->

##Example

Update is possible with a TuplesList or a Dict (and OrderedDict)