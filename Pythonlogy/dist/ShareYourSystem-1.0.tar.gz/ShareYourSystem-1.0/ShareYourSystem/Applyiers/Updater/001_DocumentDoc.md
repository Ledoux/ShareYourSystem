
<!--
FrozenIsBool False
-->

#Updater

##Doc
----


> 
> An Updater maps a __setitem__
> 
> 

----

<small>
View the Updater notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Updater.ipynb)
</small>

