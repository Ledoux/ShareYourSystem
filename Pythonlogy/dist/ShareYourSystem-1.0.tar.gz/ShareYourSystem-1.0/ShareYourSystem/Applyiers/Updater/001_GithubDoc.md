
<!--
FrozenIsBool False
-->

View the Updater sources on [Github](https://github.com/Ledoux/ShareYourSystem/tree/master/ShareYourSystem/Applyiers/Installer)

