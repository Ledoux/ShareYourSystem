
<!--
FrozenIsBool False
-->

#Applyier

##Doc
----


> 
> An Applyier apply a function thanks to a ApplyingMethodStr and an ApplyingArgDict.
> This property is going to be useful to begin to establish mappping methods and 
> commanding calls in deep structures.
> 
> 

----

<small>
View the Applyier notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Applyier.ipynb)
</small>

