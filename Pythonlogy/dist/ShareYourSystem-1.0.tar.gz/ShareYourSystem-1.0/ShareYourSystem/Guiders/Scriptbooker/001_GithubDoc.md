
<!--
FrozenIsBool False
-->

#Scriptbooker

----------------------- ------------------------------------



@Date : Fri Nov 14 13:20:38 2014 

@Author : Erwan Ledoux 



The Installer directs a readme call in a ShareYourSystem directory. 



----------------------------------------------------------------


View the Scriptbooker sources on [Github](https://github.com/Ledoux/ShareYourSystem/tree/master/ShareYourSystem.Guiders.Informer)

