
<!---
FrozenIsBool True
-->

##Example

Let's create a Slide Presentation like file