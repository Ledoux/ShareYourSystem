
<!---
FrozenIsBool True
-->

##Example

SYS is a classed Module, for easy import other submodules.