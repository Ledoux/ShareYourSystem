#<ImportSpecificModules>
import ShareYourSystem as SYS
#</ImportSpecificModules>

"""
print(SYS.Joiner.attest_flush())
#SYS.JoinerClass().test()
"""

class A():
	a=property()
	def default_init(self):
		pass

myA=A()

print(A.a.__doc__)