
<!--
FrozenIsBool False
-->

#Joiner

##Doc
----


> Joiner instances helps to flush in joined databases, get the corresponding
> RetrieveIndexesLists if it was already flushed, and then flush locally
> depending if it is a new row compared to all JoinedRetrieveIndexesListsList
> 
> 

----

<small>
View the Joiner notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Joiner.ipynb)
</small>

