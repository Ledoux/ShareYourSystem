
<!---
FrozenIsBool True
-->

##Example

Let's do a hierarchic components join