
<!--
FrozenIsBool False
-->

#Flusher

##Doc
----


> 
> Flusher instances can flush a RowedVariablesList into a table
> checking maybe before if this line is new in the table or not
> depending on identifying items.
> 
> 

----

<small>
View the Flusher notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Flusher.ipynb)
</small>

