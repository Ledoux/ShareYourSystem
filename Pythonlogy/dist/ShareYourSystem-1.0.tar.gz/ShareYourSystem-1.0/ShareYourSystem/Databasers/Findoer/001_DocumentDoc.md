
<!--
FrozenIsBool False
-->

#Findoer

##Doc
----


> 
> Findoer (sorry Finder is already an important module in python standards, so just to be sure to not override...)
> instances helps to find in a hdf5 table RowedVariablesList corresponding to the FindingConditionTuplesList.
> 
> 

----

<small>
View the Findoer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Findoer.ipynb)
</small>

