#<ImportSpecificModules>
import ShareYourSystem as SYS
#</ImportSpecificModules>

print(SYS.Merger.attest_retrieve())
#SYS.MergerClass().attest()
#SYS.MergerClass().test()
