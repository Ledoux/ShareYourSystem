
<!--
FrozenIsBool False
-->

#Merger

##Doc
----


> 
> Merger instances help for reloading rowed variables from
> different tables but with different shaping variables. 
> The results is a list of rowed items from merged tables.
> 
> 

----

<small>
View the Merger notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Merger.ipynb)
</small>

