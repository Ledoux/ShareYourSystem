
<!--
FrozenIsBool False
-->

#Databaser

##Doc
----


> 
> A Databaser rises to the DatabaserClass. This latter is the deepest class for instancing
> Variables able to store values in hierarchic tables. Here, as a first step,
> the database method helps to set the <DatabasingKeyStr> in the __dict__
> 
> 

----

<small>
View the Databaser notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Databaser.ipynb)
</small>

