
<!--
FrozenIsBool False
-->

#Featurer

##Doc
----


> 
> Featurer instances helps for defining Databaser where all 
> the rowed variables are identifying items. 
> 
> 

----

<small>
View the Featurer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Featurer.ipynb)
</small>

