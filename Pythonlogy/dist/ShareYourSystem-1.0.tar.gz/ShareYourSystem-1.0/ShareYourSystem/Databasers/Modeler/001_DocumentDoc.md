
<!--
FrozenIsBool False
-->

#Modeler

##Doc
----


> 
> The Modeler defines the model to be stored in a database like Django or PyTable.
> Here are defined the relations between attributes of an instance and their corresponding
> types in the databased structures.
> 
> 

----

<small>
View the Modeler notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Modeler.ipynb)
</small>

