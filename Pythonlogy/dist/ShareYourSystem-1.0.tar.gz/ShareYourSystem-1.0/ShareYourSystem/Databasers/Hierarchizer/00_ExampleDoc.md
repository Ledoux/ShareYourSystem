
<!---
FrozenIsBool True
-->

##Example

Note that the joined catched databases doesn't make flush the attentioned ones.
This is going to be implemented in the hierarchizer module