
<!---
FrozenIsBool True
-->

##Example

Let's do all at the same time :
Results-Parameters join and hierarchic joins.