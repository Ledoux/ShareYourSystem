
<!--
FrozenIsBool False
-->

#Hierarchizer

##Doc
----


> 
> A Hierarchizer is a Joiner that taking care of the 
> order of the joining connections between derived Joiners,
> whatever is the level of their setting in the hierarchy of 
> their parent derived Storers.
> 
> 

----

<small>
View the Hierarchizer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Hierarchizer.ipynb)
</small>

