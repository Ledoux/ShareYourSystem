#<ImportSpecificModules>
import ShareYourSystem as SYS
#</ImportSpecificModules>

print(SYS.Joiner.attest_join())
#SYS.JoinerClass().test()

