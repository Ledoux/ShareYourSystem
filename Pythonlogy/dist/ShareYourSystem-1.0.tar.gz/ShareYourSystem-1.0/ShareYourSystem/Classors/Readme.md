

<!--
FrozenIsBool False
-->

#Classors

##Doc
----


>
> The Objects helps ...
>
>

----

<small>
View the Classors notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyo
ursystem.ouvaton.org/Classors.ipynb)
</small>




<!--
FrozenIsBool False
-->

##Concept

<iframe width="650" height="300"
src="https://shareyoursystem.ouvaton.org/Classors.php">
  Fallback text here for unsupporting browsers, of which there are scant few.
</iframe>

<small>
View the Classors concept on
[Ouvaton](https://shareyoursystem.ouvaton.org/Classors.php)
</small>




<!--
FrozenIsBool False
-->

##Code

----

<ClassDocStr>

----

```python
# -*- coding: utf-8 -*-
"""


<DefineSource>
@Date : Fri Nov 14 13:20:38 2014 \n
@Author : Erwan Ledoux \n\n
</DefineSource>


The Objects helps ...

"""

#<DefineConcept>
import ShareYourSystem as SYS
SYS.setConceptModule(globals())
#</DefineConcept>

```

<small>
View the Classors sources on [Github](https://github.com/Ledoux/ShareYourSystem/
tree/master/ShareYourSystem/Classors)
</small>


