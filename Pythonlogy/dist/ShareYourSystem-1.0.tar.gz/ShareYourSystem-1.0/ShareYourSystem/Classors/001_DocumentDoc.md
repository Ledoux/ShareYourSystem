
<!--
FrozenIsBool False
-->

#Classors

##Doc
----


> 
> The Objects helps ...
> 
> 

----

<small>
View the Classors notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Classors.ipynb)
</small>

