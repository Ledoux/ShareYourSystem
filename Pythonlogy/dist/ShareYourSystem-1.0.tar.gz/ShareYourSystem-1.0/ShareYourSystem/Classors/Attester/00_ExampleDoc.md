
<!---
FrozenIsBool True
-->

##Example

Here we just decorate an IncrementerClass with an Attester and define an attest_increment
function in the module that for which an AttestingStr will be written in a local Folder 
Attests/