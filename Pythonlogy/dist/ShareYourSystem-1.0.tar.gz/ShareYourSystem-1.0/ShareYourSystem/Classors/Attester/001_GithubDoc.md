
<!--
FrozenIsBool False
-->

View the Attester sources on [Github](https://github.com/Ledoux/ShareYourSystem/tree/master/ShareYourSystem/Classors/Installer)

