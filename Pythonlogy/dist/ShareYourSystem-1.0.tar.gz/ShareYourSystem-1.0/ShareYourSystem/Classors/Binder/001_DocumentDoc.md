
<!--
FrozenIsBool False
-->

#Binder

##Doc
----


> 
> Binder helps for setting a method in a Class,
> taking inspiration (like a decoration) from another one.
> 
> 
> 

----

<small>
View the Binder notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Binder.ipynb)
</small>

