
<!--
FrozenIsBool False
-->

#Switcher

##Doc
----


> 
> The Switcher
> 
> 

----

<small>
View the Switcher notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Switcher.ipynb)
</small>

