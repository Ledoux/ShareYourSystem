
<!--
FrozenIsBool False
-->

#Inspecter

##Doc
----


> 
> An Inspecter decorates a class by giving it an InspectedArgumentDict that is 
> an inspection of all defined methods.
> 

----

<small>
View the Inspecter notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Inspecter.ipynb)
</small>

