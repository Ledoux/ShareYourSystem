
<!--
FrozenIsBool False
-->

#Watcher

##Doc
----


> 
> The Watcher 
> 
> 

----

<small>
View the Watcher notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Watcher.ipynb)
</small>

