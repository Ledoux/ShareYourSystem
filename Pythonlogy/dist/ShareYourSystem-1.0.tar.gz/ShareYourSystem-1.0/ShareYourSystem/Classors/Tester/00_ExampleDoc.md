
<!---
FrozenIsBool True
-->

##Example

The Incrementer from the previous Attester Module is now tested from its corresponding attesting function
attest_increment. Here a test_increment method is implicitely defined in a unittest class and when we call
the test method, a unittest.run is done.