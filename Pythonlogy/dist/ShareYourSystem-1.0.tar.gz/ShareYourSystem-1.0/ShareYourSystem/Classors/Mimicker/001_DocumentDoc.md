
<!--
FrozenIsBool False
-->

#Mimicker

##Doc
----


> 
> Mimicker...
> 
> 

----

<small>
View the Mimicker notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Mimicker.ipynb)
</small>

