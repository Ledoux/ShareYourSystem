

    BLLAazaddsdsdb

#Salut



    
    from pylab import *
    plot([4,5],[5,6],'o')
    class Apple():
        def eat(self):
            pass


![png](Readme_files/Readme_2_0.png)



    
