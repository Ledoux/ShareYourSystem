#ImportModules
import ShareYourSystem as SYS

#_print
SYS._print(SYS.ClassStrsList)

#print
print(SYS.PatherClass)

#print
print(SYS.Systemer)