
<!--
FrozenIsBool False
-->

#Lifer

##Doc
----


> 
> A Lifer
> 
> 

----

<small>
View the Lifer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Lifer.ipynb)
</small>

