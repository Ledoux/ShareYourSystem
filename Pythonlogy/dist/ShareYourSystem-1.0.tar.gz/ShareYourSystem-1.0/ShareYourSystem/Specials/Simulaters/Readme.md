

<!--
FrozenIsBool False
-->

#Simulaters

##Doc
----


>
> The Objects helps ...
>
>

----

<small>
View the Simulaters notebook on [NbViewer](http://nbviewer.ipython.org/url/share
yoursystem.ouvaton.org/Simulaters.ipynb)
</small>




<!--
FrozenIsBool False
-->

##Concept and SubModules family

<script type="text/javascript">

        var HrefStr=window.location.href;
        //alert(window.location.href)

        if(HrefStr ==
"http://shareyoursystem.ouvaton.org/site/LibraryReference/Simulaters/"){

            //alert('Ouvaton')
            document.write("from ")
            document.write("http://shareyoursystem.ouvaton.org/slides/ ")
            document.write("<iframe width=\"725\" height=\"300\" src=\"")
            document.write("http://shareyoursystem.ouvaton.org")
            document.write("/slides/Simulaters.php\"></iframe>")
        }
        else if(HrefStr ==
"http://127.0.0.1:8000/LibraryReference/Simulaters/"){

        //alert('Localhost')
        document.write("from ")
        document.write("localhost mkdocs but direct to ouvaton")
        document.write("<iframe width=\"725\" height=\"300\" src=\"")
        document.write("http://shareyoursystem.ouvaton.org")
        document.write("/slides/Simulaters.php\"></iframe>")
    }
    else
    {

        //alert('Local')
            document.write("from ")
            document.write("/Users/ledoux/Documents/ShareYourSystem/Ouvaton/ ")
            document.write("<iframe width=\"725\" height=\"300\" src=\"")
            document.write("/Users/ledoux/Documents/ShareYourSystem/Ouvaton/")
            document.write("Simulaters.html\"></iframe>")

    }

</script>

<small>
View the Simulaters concept on <a
href="http://shareyoursystem.ouvaton.org/slides/Simulaters.php"
target="_blank">Ouvaton</a>
</small>




<!--
FrozenIsBool False
-->

##Code

----

<ClassDocStr>

----

```python
# -*- coding: utf-8 -*-
"""


<DefineSource>
@Date : Fri Nov 14 13:20:38 2014 \n
@Author : Erwan Ledoux \n\n
</DefineSource>


The Objects helps ...

"""

#<DefineConcept>
import ShareYourSystem as SYS
SYS.setConceptModule(globals())
#</DefineConcept>

```

<small>
View the Simulaters sources on <a href="https://github.com/Ledoux/ShareYourSyste
m/tree/master/Pythonlogy/ShareYourSystem/Simulaters" target="_blank">Github</a>
</small>


