
<!--
FrozenIsBool False
-->

#Dynamizer

##Doc
----


> 
> A Dynamizer
> 
> 

----

<small>
View the Dynamizer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Dynamizer.ipynb)
</small>

