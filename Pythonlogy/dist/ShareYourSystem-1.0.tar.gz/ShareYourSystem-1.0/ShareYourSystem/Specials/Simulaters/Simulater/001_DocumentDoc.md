
<!--
FrozenIsBool False
-->

#Simulater

##Doc
----


> 
> A Simulater
> 
> 

----

<small>
View the Simulater notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Simulater.ipynb)
</small>

