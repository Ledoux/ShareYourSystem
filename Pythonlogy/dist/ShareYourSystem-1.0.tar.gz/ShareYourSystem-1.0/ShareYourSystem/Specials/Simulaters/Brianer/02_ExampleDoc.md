
<!--
FrozenIsBool False
-->

##Example

Note now that equation parts relied on the synaptic interactions
can be completely incorcoprate din our Synapsers object