
<!--
FrozenIsBool False
-->

##Example

Let's invent a rate model