
<!--
FrozenIsBool False
-->

#Runner

##Doc
----


> 
> A Runner
> 
> 

----

<small>
View the Runner notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Runner.ipynb)
</small>

