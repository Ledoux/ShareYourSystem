
<!--
FrozenIsBool False
-->

##Example

An Expresser helps to define an expression string that will then used maybe 
for building a equation in a brianer or pydelayer...
When ExpressingMapBool is false, it just builds one single expressin element.