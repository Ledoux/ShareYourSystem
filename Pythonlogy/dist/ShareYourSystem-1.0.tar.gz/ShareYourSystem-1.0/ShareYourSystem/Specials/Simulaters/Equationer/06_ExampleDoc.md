
<!--
FrozenIsBool False
-->

##Example

Here is the example with matrixer that shapes the input terms.
