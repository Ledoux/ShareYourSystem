
<!--
FrozenIsBool False
-->

##Example

And actually specifying the param value in the params dict doesn't avoid
the compilation at each time.
