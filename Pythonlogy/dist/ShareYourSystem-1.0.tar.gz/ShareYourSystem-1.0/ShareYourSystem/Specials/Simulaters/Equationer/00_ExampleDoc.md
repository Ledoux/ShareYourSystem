
<!--
FrozenIsBool False
-->

##Example

An equationer can be collected by a Pydelayer to make solve its EquationingDifferentialDict. Note that the pydelay recompile at each time because 
the equation is changing its form every time because of the random ParamInt.
