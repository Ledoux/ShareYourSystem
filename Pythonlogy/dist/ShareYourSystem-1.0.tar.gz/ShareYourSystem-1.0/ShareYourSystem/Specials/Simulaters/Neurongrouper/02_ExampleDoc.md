
<!--
FrozenIsBool False
-->

##Example

Pydelayer with rate