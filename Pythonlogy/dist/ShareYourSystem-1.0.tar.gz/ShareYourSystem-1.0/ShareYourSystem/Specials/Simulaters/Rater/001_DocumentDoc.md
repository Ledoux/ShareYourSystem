
<!--
FrozenIsBool False
-->

#Rater

##Doc
----


> 
> A Rater
> 
> 

----

<small>
View the Rater notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Rater.ipynb)
</small>

