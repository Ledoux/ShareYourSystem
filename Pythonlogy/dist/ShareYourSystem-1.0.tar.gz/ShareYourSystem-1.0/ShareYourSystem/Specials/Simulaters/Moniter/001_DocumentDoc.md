
<!--
FrozenIsBool False
-->

#Moniter

##Doc
----


> 
> A Moniter
> 
> 

----

<small>
View the Moniter notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Moniter.ipynb)
</small>

