
#ImportModules
import ShareYourSystem as SYS
	
#Definition the AttestedStr
SYS._attest(
	[
		'MyVexflower is '+SYS._str(
		MyVexflower,
		**{
			'RepresentingBaseKeyStrsListBool':False,
			'RepresentingAlineaIsBool':False
		}
	)]
) 

#Print

