
#ImportModules
import ShareYourSystem as SYS

#init
MyStreamer=SYS.StreamerClass(
	).stream(
		['C4','E4']
	)

#print
print(MyStreamer)
