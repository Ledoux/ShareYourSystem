
<!--
FrozenIsBool False
-->

##Example

Let's take the first example in the brian tutorial