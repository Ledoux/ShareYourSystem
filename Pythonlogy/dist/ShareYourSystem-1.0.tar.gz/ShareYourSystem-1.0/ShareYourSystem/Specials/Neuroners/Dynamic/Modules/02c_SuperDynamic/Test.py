#<ImportSpecificModules>
import ShareYourSystem as SYS
#</ImportSpecificModules>

SuperDynamic=SYS.SuperDynamicClass().__setitem__(
                    'TestingAttestFunctionStrsList',
                    [
                      #'attest_default', 
                      'attest_output',
                      #'attest_store',
                      #'attest_scan'
                    ]
                  )
#SuperDynamic.attest()
SuperDynamic.output().plot().show()
#SuperDynamic.test()
#import numpy as np
#print(np.array([  5.03418557e+1,   1.25013463e+77]))


#print(1+5.03418557e+2)
#import numpy as np
#print(np.sqrt(-1)==np.sqrt(-1))
#import numpy as np
#print(np.argmax(np.array([4,5,6])==5))


