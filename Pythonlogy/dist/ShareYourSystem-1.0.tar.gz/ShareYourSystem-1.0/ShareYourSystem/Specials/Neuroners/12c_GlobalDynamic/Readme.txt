The BrianedNetwork is a PopulationNetwork
with a wrapped Brian MagicNetwork
