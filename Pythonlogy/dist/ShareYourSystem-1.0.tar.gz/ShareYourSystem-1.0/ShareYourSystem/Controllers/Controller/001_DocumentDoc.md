
<!--
FrozenIsBool False
-->

#Controller

##Doc
----


> 
> A Controller
> 
> 

----

<small>
View the Controller notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Controller.ipynb)
</small>

