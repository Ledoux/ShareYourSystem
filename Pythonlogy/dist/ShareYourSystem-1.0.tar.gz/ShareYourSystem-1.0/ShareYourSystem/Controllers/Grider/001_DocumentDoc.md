
<!--
FrozenIsBool False
-->

#Grider

##Doc
----


> 
> Grider instances
> 
> 

----

<small>
View the Grider notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Grider.ipynb)
</small>

