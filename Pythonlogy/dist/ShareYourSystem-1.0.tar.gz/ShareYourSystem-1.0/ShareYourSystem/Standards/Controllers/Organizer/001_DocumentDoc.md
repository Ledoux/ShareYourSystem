
<!--
FrozenIsBool False
-->

#Organizer

##Doc
----


> 
> Organizer instances
> 
> 

----

<small>
View the Organizer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Organizer.ipynb)
</small>

