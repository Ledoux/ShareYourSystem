
<!--
FrozenIsBool False
-->

#Storers

##Doc
----


> 
> The Storers are the derived Noders that build the standard "Controller"
> part of the MVC architecture.
> 
> 

----

<small>
View the Storers notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Storers.ipynb)
</small>

