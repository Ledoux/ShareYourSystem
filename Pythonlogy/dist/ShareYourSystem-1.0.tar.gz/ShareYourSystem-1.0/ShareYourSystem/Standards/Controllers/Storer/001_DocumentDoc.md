
<!--
FrozenIsBool False
-->

#Storer

##Doc
----


> 
> Storer instances
> 
> 

----

<small>
View the Storer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Storer.ipynb)
</small>

