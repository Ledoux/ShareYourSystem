
<!---
FrozenIsBool True
-->

##Example

Let's do just for a simple example a grid that corresponds to a scan at a single level
of hierarchy.