
<!---
FrozenIsBool True
-->

##Example

Now we do a grid that first grid in each sub components, get the retrive index lists 
and so do the scan in the upper layers with all the combiations of retrieve lists.