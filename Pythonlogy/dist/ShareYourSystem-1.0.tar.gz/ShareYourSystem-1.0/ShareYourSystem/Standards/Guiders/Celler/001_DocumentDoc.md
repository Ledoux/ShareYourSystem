
<!--
FrozenIsBool False
-->

#Celler

##Doc
----


> 
> The Celler defines template of Mardown and Code Cells for readming a Module.
> 
> 

----

<small>
View the Celler notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Celler.ipynb)
</small>

