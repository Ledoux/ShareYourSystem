
<!--
FrozenIsBool False
-->

#Guiders

##Doc
----


> 
> The Objects helps ...
> 
> 

----

<small>
View the Guiders notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Guiders.ipynb)
</small>

