
<!--
FrozenIsBool False
-->

#Installer

##Doc
----


> 
> The Installer collects ModuleStrs to write 
> 
> 

----

<small>
View the Installer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Installer.ipynb)
</small>

