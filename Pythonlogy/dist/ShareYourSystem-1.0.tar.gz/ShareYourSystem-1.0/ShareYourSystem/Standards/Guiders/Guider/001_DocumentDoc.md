
<!--
FrozenIsBool False
-->

#Guider

##Doc
----


> 
> The Guider write templated .py or .md files for explaining how
> work a certain Module
> 
> 

----

<small>
View the Guider notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Guider.ipynb)
</small>

