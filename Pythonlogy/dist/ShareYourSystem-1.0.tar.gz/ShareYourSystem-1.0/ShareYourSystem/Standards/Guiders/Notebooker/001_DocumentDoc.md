
<!--
FrozenIsBool False
-->

#Notebooker

##Doc
----


> 
> The Notebooker takes piece of .md,.py,.tex files for putting them in a IPython Notebook
> 
> 

----

<small>
View the Notebooker notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Notebooker.ipynb)
</small>

