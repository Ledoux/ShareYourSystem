
<!--
FrozenIsBool False
-->

#Scriptbooker

##Doc
----


> 
> The Scriptbooker defines template of Mardown and Code Scriptbooks for readming a Module.
> 
> 

----

<small>
View the Scriptbooker notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Scriptbooker.ipynb)
</small>

