
<!--
FrozenIsBool False
-->

#Statuser

##Doc
----


> 
> The Statuser
> 
> 

----

<small>
View the Statuser notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Statuser.ipynb)
</small>

