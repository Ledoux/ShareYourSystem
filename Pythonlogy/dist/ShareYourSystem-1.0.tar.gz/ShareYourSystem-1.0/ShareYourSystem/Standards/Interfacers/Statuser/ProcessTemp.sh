OUTPUT="$(ps -ef | grep mongod)"
echo "${OUTPUT}" > /Users/ledoux/Documents/ShareYourSystem/Pythonlogy/ShareYourSystem/Standards/Interfacers/Statuser/ProcessTemp.txt