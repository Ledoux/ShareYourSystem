
<!--
FrozenIsBool False
-->

#Closer

##Doc
----


> 
> The Closer
> 

----

<small>
View the Closer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Closer.ipynb)
</small>

