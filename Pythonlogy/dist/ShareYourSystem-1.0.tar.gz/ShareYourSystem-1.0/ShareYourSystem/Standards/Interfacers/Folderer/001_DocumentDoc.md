
<!--
FrozenIsBool False
-->

#Folderer

##Doc
----


> 
> The Folderer is a quick object helping for getting the FolderedDirKeyStrsList
> at a specified directory or in the current one by default
> 
> 

----

<small>
View the Folderer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Folderer.ipynb)
</small>

