
<!--
FrozenIsBool False
-->

##Example