
<!--
FrozenIsBool False
-->

#Loader

##Doc
----


> 
> The Loader is a quick object to load from a FiledFileVariable a LoadedReadVariable
> 
> 

----

<small>
View the Loader notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Loader.ipynb)
</small>

