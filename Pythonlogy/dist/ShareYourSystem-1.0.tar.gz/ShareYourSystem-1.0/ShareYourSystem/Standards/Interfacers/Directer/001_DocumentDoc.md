
<!--
FrozenIsBool False
-->

#Directer

##Doc
----


> 
> The Directer is a walker through the folders of the harddrive, 
> assuring a call of _DirectingCallbackFunction at each level.
> 
> 

----

<small>
View the Directer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Directer.ipynb)
</small>

