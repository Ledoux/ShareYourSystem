
<!--
FrozenIsBool False
-->

#Capturer

##Doc
----


> 
> The Capturer
> 
> 

----

<small>
View the Capturer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Capturer.ipynb)
</small>

