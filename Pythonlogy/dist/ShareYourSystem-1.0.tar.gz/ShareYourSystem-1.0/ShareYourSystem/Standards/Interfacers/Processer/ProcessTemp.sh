OUTPUT="$(which python )"
echo "${OUTPUT}" > /Users/ledoux/Documents/ShareYourSystem/Pythonlogy/ShareYourSystem/Interfacers/Processer/ProcessTemp.txt