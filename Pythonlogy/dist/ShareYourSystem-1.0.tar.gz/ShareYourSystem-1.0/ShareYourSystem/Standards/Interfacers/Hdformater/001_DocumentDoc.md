
<!--
FrozenIsBool False
-->

#Hdformater

##Doc
----


> 
> An Hdformater instance maps an apply and so "grinds" a MappingArgDictsList 
> to a method.
> 
> 

----

<small>
View the Hdformater notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Hdformater.ipynb)
</small>

