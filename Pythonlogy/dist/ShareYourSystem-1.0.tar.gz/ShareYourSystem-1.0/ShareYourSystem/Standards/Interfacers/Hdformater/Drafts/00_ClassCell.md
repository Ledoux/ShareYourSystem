
<!--
FrozenIsBool False
-->

##More Descriptions at the level of the class

Special attributes of the DraftsClass are :
