
#FrozenIsBool False

#ImportModules
from ShareYourSystem.Standards.Classors import Attester
from ShareYourSystem.Standards.Objects.Hdformater import Drafts
		
#Definition the AttestedStr
SYS._attest(
	[
		Drafts.DraftsClass()
	]
) 

#Print


