
<!--
FrozenIsBool False
-->

#Filer

##Doc
----


> 
> The Filer is a quick object for opening a FiledFileVariable and safely using (read,write) 
> it depending on the FiledModeStr.
> 
> 

----

<small>
View the Filer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Filer.ipynb)
</small>

