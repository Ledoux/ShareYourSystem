OUTPUT="$(ps -ef | grep mongod)"
echo "${OUTPUT}" > /Users/ledoux/Documents/ShareYourSystem/Pythonlogy/ShareYourSystem/Standards/Interfacers/Killer/ProcessTemp.txt