
<!--
FrozenIsBool False
-->

#Killer

##Doc
----


> 
> The Killer
> 
> 

----

<small>
View the Killer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Killer.ipynb)
</small>

