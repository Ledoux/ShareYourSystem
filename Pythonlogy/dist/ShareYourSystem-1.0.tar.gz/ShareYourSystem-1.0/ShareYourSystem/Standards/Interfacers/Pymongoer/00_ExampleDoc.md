
<!---
FrozenIsBool True
-->

##Example

Pymongo for creating one Default Database with one collection.