
<!--
FrozenIsBool False
-->

#Interfacer

----


> 
> @Date : Fri Nov 14 13:20:38 2014 
> 
> @Author : Erwan Ledoux 
> 
> 
> 
> The Interfacer
> 
> 

----


View the Interfacer sources on [Github](https://github.com/Ledoux/ShareYourSystem/tree/master/ShareYourSystem/Interfacers/Interfacer)

