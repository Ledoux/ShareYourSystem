
<!--
FrozenIsBool False
-->

#Interfacer

##Doc
----


> 
> The Interfacer
> 
> 

----

<small>
View the Interfacer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Interfacer.ipynb)
</small>

