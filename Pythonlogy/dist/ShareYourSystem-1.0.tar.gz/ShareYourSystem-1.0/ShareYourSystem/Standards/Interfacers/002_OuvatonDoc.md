
<!--
FrozenIsBool False
-->

##Concept and SubModules family

<script type="text/javascript">

	var HrefStr=window.location.href;
	//alert(window.location.href)

	if(HrefStr == "http://shareyoursystem.ouvaton.org/site/LibraryReference/Interfacers/"){

	    //alert('Ouvaton')
	    document.write("from ")
	    document.write("http://shareyoursystem.ouvaton.org/slides/ ")
	    document.write("<iframe width=\"725\" height=\"300\" src=\"")
	    document.write("http://shareyoursystem.ouvaton.org")
	    document.write("/slides/Interfacers.php\"></iframe>")
	}
	else if(HrefStr == "http://127.0.0.1:8000/LibraryReference/Interfacers/"){

        //alert('Localhost')
        document.write("from ")
        document.write("localhost mkdocs but direct to ouvaton")
        document.write("<iframe width=\"725\" height=\"300\" src=\"")
        document.write("http://shareyoursystem.ouvaton.org")
        document.write("/slides/Interfacers.php\"></iframe>")
    }
    else
    {

        //alert('Local')
	    document.write("from ")
	    document.write("/Users/ledoux/Documents/ShareYourSystem/Ouvaton/ ")
	    document.write("<iframe width=\"725\" height=\"300\" src=\"")
	    document.write("/Users/ledoux/Documents/ShareYourSystem/Ouvaton/")
	    document.write("Interfacers.html\"></iframe>")

    }

</script>

<small>
View the Interfacers concept on <a href="http://shareyoursystem.ouvaton.org/slides/Interfacers.php" target="_blank">Ouvaton</a>
</small>

