
<!--
FrozenIsBool False
-->

#Attester

##Doc
----


> 
> The Attester helps for outputing and writing
> AttestingPrefixStrs that are a succession of well-shaped
> prints in the console from an defined attesting function.
> This environment helps for displaying nicer exampling 
> python codes in Readme and also contributing to unittests
> of the modules.
> 
> 

----

<small>
View the Attester notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Attester.ipynb)
</small>

