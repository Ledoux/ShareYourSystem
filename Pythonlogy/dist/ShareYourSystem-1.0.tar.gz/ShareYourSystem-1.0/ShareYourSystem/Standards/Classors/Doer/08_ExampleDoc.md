
<!---
FrozenIsBool True
-->

##Example

It is possible to re set the Doing or Done attributes