
<!---
FrozenIsBool True
-->

##Example

Now we add a wrapped do_make method