
<!---
FrozenIsBool True
-->

##Example

The call of the do method initializes also the 
object that has to be setted at the level of the instance