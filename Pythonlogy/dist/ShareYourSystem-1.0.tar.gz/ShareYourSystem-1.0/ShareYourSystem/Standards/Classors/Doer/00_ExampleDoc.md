
<!---
FrozenIsBool True
-->

##Example

Let's invent our first class decorated by a Doer, the MakerClass
that will have the job of casting a Float into a Int... 