
<!---
FrozenIsBool True
-->

##Example

Here this is to check that the class checks that 
this is useless to watch a watch method, therefore it
just lets it as the first version. 