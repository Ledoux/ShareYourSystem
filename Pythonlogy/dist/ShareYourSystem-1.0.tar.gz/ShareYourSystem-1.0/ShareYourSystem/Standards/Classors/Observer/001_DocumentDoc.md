
<!--
FrozenIsBool False
-->

#Observer

##Doc
----


> 
> Observer...
> 
> 

----

<small>
View the Observer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Observer.ipynb)
</small>

