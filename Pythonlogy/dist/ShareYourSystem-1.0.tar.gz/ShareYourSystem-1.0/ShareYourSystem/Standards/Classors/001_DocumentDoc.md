
<!--
FrozenIsBool False
-->

#Classors

##Doc
----


> The Classors help for decorating a Class. 
> Here are defined the important derived Objects that
> facilitates the manners to set a new defined Class in the 
> SYS scope and set automatically into it new 'boilerplates'
> methods like the 'default_init' (cf. Defaultor),'do_<DoMethodStr>'
>  (cf. Doer), 'mimic_<DoMethodStr>' (cf. Mimicker), also
>  decorates methods for making it switch or resetting.
> 
> 

----

<small>
View the Classors notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Classors.ipynb)
</small>

