
<!--
FrozenIsBool False
-->

#Propertiser

##Doc
----


> 
> The Propertiser is an augmented Defaultor because it will set defaults attributes
> possibly in properties for the new-style decorated classes. This can set objects
> with high controlling features thanks to the binding 
> 
> 

----

<small>
View the Propertiser notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Propertiser.ipynb)
</small>

