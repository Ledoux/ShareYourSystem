
<!---
FrozenIsBool True
-->

##Example

Going back to the Doer cell when we invented a very minimalist Maker.
We now define its MakingMyFloat as a property that can be then defined as 
a "binding" attribute thanks to the setMakingMyFloat method definition, 
that will be linked to the fset attribute of the property object. 