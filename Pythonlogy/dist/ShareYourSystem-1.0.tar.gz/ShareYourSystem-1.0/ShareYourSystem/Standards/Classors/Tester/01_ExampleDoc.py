#ImportModules
import ShareYourSystem as SYS

#Attest the module
SYS.DecrementerClass().setAttest(
	Tester.TesterClass.DeriveClassor.AttestingFolderPathStr
)
SYS.Decrementer.test()

#Print

