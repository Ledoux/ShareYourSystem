
<!--
FrozenIsBool False
-->

#Tester

##Doc
----


> 
> The Tester helps for defining asserts between 
> attested Strs stored in the Attests Folder and
> new calls of the attest functions. Thanks here 
> to a wrap of the unitest python module :
> https://docs.python.org/2/library/unittest.html
> 
> 

----

<small>
View the Tester notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Tester.ipynb)
</small>

