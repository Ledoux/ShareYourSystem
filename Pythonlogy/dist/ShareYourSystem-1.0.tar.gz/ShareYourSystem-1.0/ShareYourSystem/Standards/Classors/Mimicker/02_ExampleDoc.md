
<!---
FrozenIsBool True
-->

##Example

It is possible to cumulate mimick and switch properties...
Note that only the do_make is a switched method as the 
mimic_make continue to work after the first call of make.