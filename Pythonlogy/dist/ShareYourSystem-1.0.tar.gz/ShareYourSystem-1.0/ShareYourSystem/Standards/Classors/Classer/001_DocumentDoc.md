
<!--
FrozenIsBool False
-->

#Classer

##Doc
----


> 
> The Classer
> 
> 

----

<small>
View the Classer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Classer.ipynb)
</small>

