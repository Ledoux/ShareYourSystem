
<!---
FrozenIsBool True
-->

##Example

First is presented the global functions _print or represent that helps for printing
in the console any kind of variables.