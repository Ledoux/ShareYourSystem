
<!---
FrozenIsBool True
-->

##Example

Then classes that are decorated by the representer have now a special __repr__ method.