
<!--
FrozenIsBool False
-->

#Deriver

##Doc
----


> 
> The Deriver helps for building a base-derive relationships between the classes.
> Once a <Class> with based classes is defined, a decorating DeriverClass instance
> append to these corresponding BaseClasses the <Class> as a derived class.
> 
> 

----

<small>
View the Deriver notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Deriver.ipynb)
</small>

