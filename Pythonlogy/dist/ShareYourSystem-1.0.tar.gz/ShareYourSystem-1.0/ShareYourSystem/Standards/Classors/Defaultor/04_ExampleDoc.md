
<!---
FrozenIsBool True
-->

##Example

Defaultot can also initialize instances at the level of the class.