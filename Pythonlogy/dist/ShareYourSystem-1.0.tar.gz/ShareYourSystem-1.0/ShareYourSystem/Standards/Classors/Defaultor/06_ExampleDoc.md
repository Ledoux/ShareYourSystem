
<!---
FrozenIsBool True
-->

##Example

It is possible to 'reboot' an instance with the default value
defined at the level of the class.
Note that the mutable variables that are initiated at the level of the class keeps
their ongoing value (as MyShareList) and that we can force or not the reset of the specific mutable arrays with the option ForceSetIsBool
