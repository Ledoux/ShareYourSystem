
<!---
FrozenIsBool True
-->

##Example

We define here a MakerClass with some making and made attributes. Here is the difference for a default instance
DefaultMaker that takes its values from the MakerClass.__dict__ and a special one that sets in its __dict__