
<!---
FrozenIsBool True
-->

##Example

We define here a FooClass with some attributes. Here is the difference for a default instance
DefaultFoo that takes its values from the FooClass.__dict__ and a special one that sets in its __dict__