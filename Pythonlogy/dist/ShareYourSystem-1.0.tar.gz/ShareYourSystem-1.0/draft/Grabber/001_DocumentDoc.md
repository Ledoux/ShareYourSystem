
<!--
FrozenIsBool False
-->

#Grabber

##Doc
----


> 
> A Grabber
> 
> 

----

<small>
View the Grabber notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Grabber.ipynb)
</small>

