
<!--
FrozenIsBool False
-->

#Weaver

##Doc
----


> 
> A Weaver
> 
> 

----

<small>
View the Weaver notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Weaver.ipynb)
</small>

