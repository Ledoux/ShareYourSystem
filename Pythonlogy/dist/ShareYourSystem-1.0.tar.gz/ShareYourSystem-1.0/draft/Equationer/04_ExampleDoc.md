
<!--
FrozenIsBool False
-->

##Example

Matrixers can be used to shape automatically the couplings between variables
Here is the example with the lateral connections and a leak term.
