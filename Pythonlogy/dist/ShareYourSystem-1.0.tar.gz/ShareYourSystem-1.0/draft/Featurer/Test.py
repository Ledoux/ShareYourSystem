#<ImportSpecificModules>
import ShareYourSystem as SYS
#</ImportSpecificModules>

print(SYS.Featurer.attest_insert())
#SYS.FeaturerClass().attest()
#SYS.FeaturerClass().test()

