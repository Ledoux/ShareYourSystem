
<!--
FrozenIsBool False
-->

##Example

When ExpressingMapBool is True, it maps a build given the ExpressingSpecific Row arrays.