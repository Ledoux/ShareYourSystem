
<!--
FrozenIsBool False
-->

#Router

##Doc
----


> 
> A Router
> 
> 

----

<small>
View the Router notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Router.ipynb)
</small>

