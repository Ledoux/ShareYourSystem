
<!--
FrozenIsBool False
-->

#Pusher

##Doc
----


> 
> Pusher instances
> 
> 

----

<small>
View the Pusher notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Pusher.ipynb)
</small>

