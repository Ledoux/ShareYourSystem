
<!--
FrozenIsBool False
-->

#Sharer

##Doc
----


> 
> A Sharer can set attributes at the level of the class
> 
> 

----

<small>
View the Sharer notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Sharer.ipynb)
</small>

