
<!--
FrozenIsBool False
-->

#Poker

##Doc
----


> 
> Poker instances
> 
> 

----

<small>
View the Poker notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Poker.ipynb)
</small>

