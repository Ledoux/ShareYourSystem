
<!--
FrozenIsBool False
-->

#Scanner

##Doc
----


> 
> Scanner instances helps for doing and flushing rows from
> a range of modeling values
>  
> 

----

<small>
View the Scanner notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Scanner.ipynb)
</small>

