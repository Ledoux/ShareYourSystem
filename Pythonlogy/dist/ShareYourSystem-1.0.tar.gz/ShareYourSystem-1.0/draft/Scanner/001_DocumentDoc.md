
<!--
FrozenIsBool False
-->

#Scanner

##Doc
----


> 
> Scanner instances helps for doing and inserting rows from
> a range of modeling values
>  
> 

----

<small>
View the Scanner notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Scanner.ipynb)
</small>

