#<ImportSpecificModules>
import ShareYourSystem as SYS
#</ImportSpecificModules>

print(SYS.Scanner.attest_scan())
#Scan.test()