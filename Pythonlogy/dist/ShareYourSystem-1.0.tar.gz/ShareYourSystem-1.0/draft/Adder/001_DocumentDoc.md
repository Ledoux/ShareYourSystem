
<!--
FrozenIsBool False
-->

#Adder

##Doc
----


> 
> An Adder maps an append
> 

----

<small>
View the Adder notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Adder.ipynb)
</small>

