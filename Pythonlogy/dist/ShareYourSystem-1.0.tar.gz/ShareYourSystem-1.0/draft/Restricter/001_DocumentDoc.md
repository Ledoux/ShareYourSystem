
<!--
FrozenIsBool False
-->

#Restricter

##Doc
----


> 
> A Restricter object sets only in the __dict__ only if hasattr(self,self.SettingKeyVariable)
> returns True before.
> 
> 

----

<small>
View the Restricter notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Restricter.ipynb)
</small>

