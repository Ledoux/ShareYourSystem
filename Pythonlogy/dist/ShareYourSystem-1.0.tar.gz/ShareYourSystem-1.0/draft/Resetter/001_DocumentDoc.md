
<!--
FrozenIsBool False
-->

#Resetter

##Doc
----


> 
> The Resetter
> 
> 

----

<small>
View the Resetter notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Resetter.ipynb)
</small>

