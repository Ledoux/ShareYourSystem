
<!--
FrozenIsBool False
-->

#Appender

##Doc
----


> 
> An Appender append by doing a set in a NodedOrderedDict thanks to the <AppendedNodeCollectionStr><AppendedNodeKeyStr>
> 
> 

----

<small>
View the Appender notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Appender.ipynb)
</small>

