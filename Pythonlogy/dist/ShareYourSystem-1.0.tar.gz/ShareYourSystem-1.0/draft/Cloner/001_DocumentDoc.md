
<!--
FrozenIsBool False
-->

#Cloner

##Doc
----


> 
> The Cloner
> 
> 

----

<small>
View the Cloner notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Cloner.ipynb)
</small>

