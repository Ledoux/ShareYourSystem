
<!--
FrozenIsBool False
-->

#Linker

##Doc
----


> 
> An Linker maps a point
> 
> 

----

<small>
View the Linker notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Linker.ipynb)
</small>

