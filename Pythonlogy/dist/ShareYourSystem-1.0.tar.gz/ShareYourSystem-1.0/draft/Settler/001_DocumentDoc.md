
<!--
FrozenIsBool False
-->

#Settler

##Doc
----


> 
> A Settler 
> 
> 

----

<small>
View the Settler notebook on [NbViewer](http://nbviewer.ipython.org/url/shareyoursystem.ouvaton.org/Settler.ipynb)
</small>

